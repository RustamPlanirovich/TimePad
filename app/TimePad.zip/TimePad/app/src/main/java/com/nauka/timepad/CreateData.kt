package com.nauka.timepad

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.nauka.timepad.databinding.ActivityCreateDataBinding
import java.sql.Time
import java.util.*

class CreateData : AppCompatActivity() {

    //view binding
    private lateinit var binding: ActivityCreateDataBinding

    private lateinit var firebaseAuth: FirebaseAuth

    private lateinit var db: FirebaseFirestore


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateDataBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()
        val firebaseUser = firebaseAuth.currentUser.uid

        binding.button.setOnClickListener {
            val user = hashMapOf(
                "name" to binding.editTextTextPersonName.text.toString(),
                "time" to binding.editTextTextPersonName2.text.toString().toLong()*60*60*1000,
                "tag" to binding.editTextTextPersonName3.text.toString()
            )


            db.collection(firebaseUser.toString()).document(binding.editTextTextPersonName.text.toString())
                .set(user)
                .addOnSuccessListener {
                    Toast.makeText(this@CreateData, "Complete", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this@CreateData, "$it", Toast.LENGTH_SHORT).show()
                }
        }

        binding.editTextTextPersonName2.setOnClickListener {
            val doc = db.collection(firebaseUser.toString()).document(binding.editTextTextPersonName.text.toString())
            doc.addSnapshotListener{ snapshot, e ->
                if (e != null){
                    return@addSnapshotListener
                }

                if (snapshot != null && snapshot.exists()){
                    binding.editTextTextPersonName2.setText(snapshot.data.toString())
                }
            }
        }

    }
}