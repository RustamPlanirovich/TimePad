package com.nauka.timepad

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.firebase.auth.FirebaseAuth
import com.nauka.timepad.databinding.ActivityProfile2Binding

class ProfileActivity2 : AppCompatActivity() {

    //view binding
    private lateinit var binding: ActivityProfile2Binding

    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfile2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()
        checkUser()

        //loggoutBtn click, Logout the user
        binding.logoutBtn.setOnClickListener {
            firebaseAuth.signOut()
            checkUser()
        }

        binding.createDb.setOnClickListener {
            startActivity(Intent(this, CreateData::class.java))
        }
    }

    private fun checkUser() {
        //get current user
        val firebaseUser = firebaseAuth.currentUser
        if (firebaseUser == null){
            //logget out
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
        else{
            //logget in, get phone number of user
            val phone = firebaseUser.phoneNumber
            //set phone number
            binding.phoneTv.text = phone
        }
    }

}